#include <bits/stdc++.h>
using namespace std;
int a[10000000];
int main()
{
    int t, a, b;
    cin>>a>>b;
    cout<<a+b<<endl;
    return 0;
}
