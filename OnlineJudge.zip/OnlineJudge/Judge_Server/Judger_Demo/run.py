import Compile
import Time_Memory_Judge
import Ans_Judge
import Judger

ans = Judger.Judge(1002, 1, 1000, 65432, "g++")
print(ans)